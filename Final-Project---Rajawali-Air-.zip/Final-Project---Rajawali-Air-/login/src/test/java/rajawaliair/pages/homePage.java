package rajawaliair.pages;

import rajawaliair.keyword;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class homePage {

    protected WebDriver webDriver;

    public homePage(WebDriver driver) {
        this.webDriver = driver;
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        PageFactory.initElements(webDriver, this);
    }
    @FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div[1]/div/div[2]/button[1]")
    private static WebElement notif_icon;

    @FindBy(xpath = "/html/body/div/div[1]/div/form/div[1]/div[2]/div[1]/div/label/div[2]")
    private static WebElement source_airport;

    @FindBy(xpath = "/html/body/div/div[1]/div/form/div[1]/div[2]/div[2]/label/div[2]")
    private static WebElement destination_aiport;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/form/div[1]/div[2]/div[5]/label/div[2]")
    private static WebElement passenger_class;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/div[2]/div")
    private static WebElement passenger_popup;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/div[2]/div/table/tbody/tr[1]/td[1]/div/div[2]/input")
    private static WebElement adult_input;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/div[2]/div/table/tbody/tr[1]/td[1]/div/div[2]/button[2]")
    private static WebElement adult_add_button;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/div[2]/div/table/tbody/tr[1]/td[2]/div")
    private static WebElement economy_button;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/div[2]/div/table/tbody/tr[4]/td[2]/button")
    private static WebElement finish_button;
//
    @FindBy(xpath = "/html/body/div/div[1]/div/form/div[2]/button")
    private static WebElement search_button;
//
//
    public static void verifyNotifIconExist(){

        keyword.validate_element_is_visible_and_enabled(notif_icon);
    }
//    public static void TapAddToCart(){
//        keyword.tapElement(add_to_cart);
//        keyword.validate_element_is_visible_and_enabled(badge_cart);
//    }
//
//    public static void doCheckout(String firstName, String lastName, String postalCode){
//        keyword.tapElement(cart_icon);
//        keyword.tapElement(checkout_button);
//        keyword.inputText(input_firstname, firstName);
//        keyword.inputText(input_lastname, lastName);
//        keyword.inputText(input_postalcode, postalCode);
//        keyword.tapElement(continue_button);
//        keyword.tapElement(finish_button);
//    }
//
//    public static void verifySuccessCheckout(){
//        keyword.validate_element_is_visible_and_enabled(success_checkout);
//    }
//
//    public static void selectFilter(String value){
//        keyword.selectOption(select_filter, value);
//    }


}
