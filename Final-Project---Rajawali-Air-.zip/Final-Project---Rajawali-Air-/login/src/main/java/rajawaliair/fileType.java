package rajawaliair;

public enum fileType {
    PNG,
    JPG,
    JPEG
}